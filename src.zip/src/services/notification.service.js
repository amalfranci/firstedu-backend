import notificationRepository from "../repository/notification.repository.js";
import studentRepository from "../repository/student.repository.js";
import teacherRepository from "../repository/teacher.repository.js";
import studentSessionRepository from "../repository/studentSession.repository.js";
import Admin from "../models/Admin.js";
import CoursePurchase from "../models/CoursePurchase.js";
import TestPurchase from "../models/TestPurchase.js";
import EventRegistration from "../models/EventRegistration.js";
import CategoryPurchase from "../models/CategoryPurchase.js";
import TestBundle from "../models/TestBundle.js";
import Tournament from "../models/Tournament.js";
import Challenge from "../models/Challenge.js";
import categoryRepository from "../repository/category.repository.js";
import {
  sendNotificationToDevice,
  sendNotificationToMultipleDevices,
} from "./fcm.service.js";

const PURCHASER_PRODUCT_TYPES = ["Course", "Test", "TestBundle", "Tournament", "Workshop"];

/**
 * Send notification to a single student
 */
export const sendNotificationToStudent = async (studentId, title, body, data = {}, sentBy) => {
  const student = await studentRepository.findById(studentId);
  if (!student) {
    throw new Error("Student not found");
  }

  const session = await studentSessionRepository.findByStudentId(studentId);
  const fcmToken = session?.fcmToken || null;

  const notification = await notificationRepository.create({
    title,
    body,
    recipient: studentId,
    sentBy,
    data,
    type: data.type || "general",
  });

  let fcmResult = null;
  if (fcmToken) {
    try {
      fcmResult = await sendNotificationToDevice(
        fcmToken,
        title,
        body,
        {
          ...data,
          audience: "student",
          notificationId: notification._id.toString(),
        }
      );

      if (fcmResult.success) {
        await notificationRepository.update(notification._id, {
          fcmSent: true,
          fcmSentAt: new Date(),
        });
      }
    } catch (error) {
      console.error("Error sending FCM notification:", error);
      if (error.code === "messaging/invalid-registration-token" ||
        error.code === "messaging/registration-token-not-registered") {
        await studentSessionRepository.updateFcmToken(studentId, null);
      }
    }
  }

  return {
    notification,
    fcmSent: fcmResult?.success || false,
  };
};

/**
 * Send notification to a single teacher (in-app + FCM when token exists)
 */
export const sendNotificationToTeacher = async (teacherId, title, body, data = {}, sentBy) => {
  const teacher = await teacherRepository.findById(teacherId);
  if (!teacher) {
    throw new Error("Teacher not found");
  }

  const notification = await notificationRepository.create({
    title,
    body,
    recipient: teacherId,
    sentBy,
    data,
    type: data.type || "general",
  });

  const fcmToken = teacher.fcmToken?.trim() || null;
  let fcmResult = null;

  if (fcmToken) {
    try {
      fcmResult = await sendNotificationToDevice(
        fcmToken,
        title,
        body,
        {
          ...data,
          audience: "teacher",
          notificationId: notification._id.toString(),
        }
      );

      if (fcmResult.success) {
        await notificationRepository.update(notification._id, {
          fcmSent: true,
          fcmSentAt: new Date(),
        });
      }
    } catch (error) {
      console.error("Error sending FCM notification to teacher:", error);
      if (
        error.code === "messaging/invalid-registration-token" ||
        error.code === "messaging/registration-token-not-registered"
      ) {
        await teacherRepository.updateById(teacherId, { fcmToken: null });
      }
    }
  }

  return {
    notification,
    fcmSent: fcmResult?.success || false,
  };
};

/**
 * Send notification to multiple students
 */
export const sendNotificationToMultipleStudents = async (
  studentIds,
  title,
  body,
  data = {},
  sentBy
) => {
  if (!studentIds || studentIds.length === 0) {
    throw new Error("No students found");
  }

  const batchSize = 500;
  let allCreatedNotifications = [];
  let totalFcmSent = 0;
  let totalFcmFailed = 0;

  for (let i = 0; i < studentIds.length; i += batchSize) {
    const chunkIds = studentIds.slice(i, i + batchSize);
    
    const studentsResult = await studentRepository.findAll(
      { _id: { $in: chunkIds } },
      { limit: batchSize }
    );
    const studentsList = studentsResult.students || [];

    if (studentsList.length === 0) continue;

    const notifications = studentsList.map((student) => ({
      title,
      body,
      recipient: student._id,
      sentBy,
      data,
      type: data.type || "general",
    }));

    const createdNotifications = await notificationRepository.createMany(notifications);
    allCreatedNotifications.push(...createdNotifications);

    const sessionMap = await studentSessionRepository.findByStudentIds(chunkIds);
    const fcmTokens = [];
    const notificationIdsForTokens = []; // Using Array instead of Map

    studentsList.forEach((student, index) => {
      const session = sessionMap.get(student._id.toString());
      const token = session?.fcmToken?.trim();
      if (token) {
        fcmTokens.push(token);
        notificationIdsForTokens.push(createdNotifications[index]._id);
      }
    });

    if (fcmTokens.length > 0) {
      try {
        const fcmResult = await sendNotificationToMultipleDevices(
          fcmTokens,
          title,
          body,
          {
            ...data,
            audience: "student",
          }
        );

        totalFcmSent += fcmResult.successCount || 0;
        totalFcmFailed += fcmResult.failureCount || 0;

        if (fcmResult.success && fcmResult.responses) {
          const bulkOps = [];
          fcmResult.responses.forEach((response, index) => {
            if (response.success) {
              const notificationId = notificationIdsForTokens[index];
              if (notificationId) {
                bulkOps.push({
                  updateOne: {
                    filter: { _id: notificationId },
                    update: { $set: { fcmSent: true, fcmSentAt: new Date() } }
                  }
                });
              }
            }
          });
          if (bulkOps.length > 0) {
            await notificationRepository.bulkWrite(bulkOps);
          }
        }
      } catch (error) {
        console.error("Error sending FCM notifications:", error);
      }
    }
  }

  if (allCreatedNotifications.length === 0) {
    throw new Error("No students found");
  }

  return {
    notifications: allCreatedNotifications,
    totalSent: allCreatedNotifications.length,
    fcmSent: totalFcmSent,
    fcmFailed: totalFcmFailed,
  };
};

/**
 * Send notification to multiple teachers
 */
export const sendNotificationToMultipleTeachers = async (
  teacherIds,
  title,
  body,
  data = {},
  sentBy
) => {
  if (!teacherIds || teacherIds.length === 0) {
    throw new Error("No teachers found");
  }

  const batchSize = 500;
  let allCreatedNotifications = [];
  let totalFcmSent = 0;
  let totalFcmFailed = 0;

  for (let i = 0; i < teacherIds.length; i += batchSize) {
    const chunkIds = teacherIds.slice(i, i + batchSize);

    const result = await teacherRepository.findAll(
      { _id: { $in: chunkIds } },
      { limit: batchSize }
    );
    const teachersList = result.teachers || [];

    if (teachersList.length === 0) continue;

    const notifications = teachersList.map((teacher) => ({
      title,
      body,
      recipient: teacher._id,
      sentBy,
      data,
      type: data.type || "general",
    }));

    const createdNotifications = await notificationRepository.createMany(notifications);
    allCreatedNotifications.push(...createdNotifications);

    const fcmTokens = [];
    const notificationIdsForTokens = [];

    teachersList.forEach((teacher, index) => {
      const token = teacher.fcmToken?.trim();
      if (token) {
        fcmTokens.push(token);
        notificationIdsForTokens.push(createdNotifications[index]._id);
      }
    });

    if (fcmTokens.length > 0) {
      try {
        const fcmResult = await sendNotificationToMultipleDevices(fcmTokens, title, body, {
          ...data,
          audience: "teacher",
        });

        totalFcmSent += fcmResult.successCount || 0;
        totalFcmFailed += fcmResult.failureCount || 0;

        if (fcmResult.success && fcmResult.responses) {
          const bulkOps = [];
          fcmResult.responses.forEach((response, index) => {
            if (response.success) {
              const notificationId = notificationIdsForTokens[index];
              if (notificationId) {
                bulkOps.push({
                  updateOne: {
                    filter: { _id: notificationId },
                    update: { $set: { fcmSent: true, fcmSentAt: new Date() } }
                  }
                });
              }
            }
          });
          if (bulkOps.length > 0) {
            await notificationRepository.bulkWrite(bulkOps);
          }
        }
      } catch (error) {
        console.error("Error sending FCM notifications to teachers:", error);
      }
    }
  }

  if (allCreatedNotifications.length === 0) {
    throw new Error("No teachers found");
  }

  return {
    notifications: allCreatedNotifications,
    totalSent: allCreatedNotifications.length,
    fcmSent: totalFcmSent,
    fcmFailed: totalFcmFailed,
  };
};

/**
 * Send notification to students who purchased any item of the given product type
 * (e.g. all test purchasers, all course purchasers, etc.)
 */
export const sendNotificationToPurchasers = async (
  productType,
  title,
  body,
  data = {},
  sentBy
) => {
  let studentIds = [];

  switch (productType) {
    case "Course":
      studentIds = await CoursePurchase.find({ paymentStatus: "completed" }).distinct("student");
      break;
    case "Test":
      studentIds = await TestPurchase.find({
        test: { $exists: true, $ne: null },
        paymentStatus: "completed",
      }).distinct("student");
      break;
    case "TestBundle":
      studentIds = await TestPurchase.find({
        testBundle: { $exists: true, $ne: null },
        paymentStatus: "completed",
      }).distinct("student");
      break;

    case "Tournament":
      studentIds = await EventRegistration.find({
        eventType: "tournament",
        paymentStatus: "completed",
      }).distinct("student");
      break;
    case "Workshop":
      studentIds = await EventRegistration.find({
        eventType: "workshop",
        paymentStatus: "completed",
      }).distinct("student");
      break;
    default:
      throw new Error(
        `Invalid productType. Must be one of: ${PURCHASER_PRODUCT_TYPES.join(", ")}`
      );
  }

  // Remove duplicates (a student may have purchased multiple items of same type)
  studentIds = [...new Set(studentIds.map((id) => id.toString()))];

  if (!studentIds || studentIds.length === 0) {
    return {
      notifications: [],
      totalSent: 0,
      fcmSent: 0,
      fcmFailed: 0,
      message: `No purchasers found for ${productType}`,
    };
  }

  const result = await sendNotificationToMultipleStudents(
    studentIds,
    title,
    body,
    { ...data, productType },
    sentBy
  );

  return {
    ...result,
    productType,
  };
};

/**
 * Send notification to all students
 */
export const sendNotificationToAllStudents = async (title, body, data = {}, sentBy) => {
  let page = 1;
  const batchSize = 500;
  const CONCURRENCY_LIMIT = 5; // Process 5 batches concurrently
  
  let activePromises = [];
  const results = [];
  let totalFound = 0;

  while (true) {
    const result = await studentRepository.findAll({}, { page, limit: batchSize });
    if (!result.students || result.students.length === 0) break;

    const batch = result.students.map((s) => s._id);
    totalFound += batch.length;

    activePromises.push(
      sendNotificationToMultipleStudents(batch, title, body, data, sentBy)
    );

    if (activePromises.length >= CONCURRENCY_LIMIT) {
      const batchResults = await Promise.all(activePromises);
      results.push(...batchResults);
      activePromises = [];
    }

    if (result.students.length < batchSize) break;
    page++;
  }

  if (activePromises.length > 0) {
    const batchResults = await Promise.all(activePromises);
    results.push(...batchResults);
  }

  if (totalFound === 0) {
    throw new Error("No students found");
  }

  // Aggregate results
  return {
    totalSent: results.reduce((sum, r) => sum + r.totalSent, 0),
    fcmSent: results.reduce((sum, r) => sum + r.fcmSent, 0),
    fcmFailed: results.reduce((sum, r) => sum + r.fcmFailed, 0),
  };
};

/**
 * Send notification to all teachers
 */
export const sendNotificationToAllTeachers = async (title, body, data = {}, sentBy) => {
  let page = 1;
  const batchSize = 500;
  const CONCURRENCY_LIMIT = 5;
  
  let activePromises = [];
  const results = [];
  let totalFound = 0;

  while (true) {
    const result = await teacherRepository.findAll({}, { page, limit: batchSize });
    if (!result.teachers || result.teachers.length === 0) break;

    const batch = result.teachers.map((t) => t._id);
    totalFound += batch.length;

    activePromises.push(
      sendNotificationToMultipleTeachers(batch, title, body, data, sentBy)
    );

    if (activePromises.length >= CONCURRENCY_LIMIT) {
      const batchResults = await Promise.all(activePromises);
      results.push(...batchResults);
      activePromises = [];
    }

    if (result.teachers.length < batchSize) break;
    page++;
  }

  if (activePromises.length > 0) {
    const batchResults = await Promise.all(activePromises);
    results.push(...batchResults);
  }

  if (totalFound === 0) {
    throw new Error("No teachers found");
  }

  return {
    totalSent: results.reduce((sum, r) => sum + r.totalSent, 0),
    fcmSent: results.reduce((sum, r) => sum + r.fcmSent, 0),
    fcmFailed: results.reduce((sum, r) => sum + r.fcmFailed, 0),
  };
};

/**
 * Get notifications for a student
 */
export const getStudentNotifications = async (studentId, options = {}) => {
  const query = { recipient: studentId };

  // Add isRead filter if provided
  if (options.isRead !== undefined) {
    query.isRead = options.isRead === true || options.isRead === "true";
  }

  return await notificationRepository.findAll(query, options);
};

/**
 * Persist an in-app notification for a teacher (recipient is Teacher _id).
 */
export const createNotificationForTeacher = async (
  teacherId,
  title,
  body,
  data = {},
  type = "system"
) => {
  return await notificationRepository.create({
    recipient: teacherId,
    title,
    body,
    data,
    type,
    sentBy: null,
  });
};

/**
 * Get notifications for a teacher
 */
export const getTeacherNotifications = async (teacherId, options = {}) => {
  const query = { recipient: teacherId };

  if (options.isRead !== undefined) {
    query.isRead = options.isRead === true || options.isRead === "true";
  }

  return await notificationRepository.findAll(query, options);
};

/**
 * Get unread notification count for a teacher
 */
export const getTeacherUnreadCount = async (teacherId) => {
  return await notificationRepository.getUnreadCount(teacherId);
};

/**
 * Mark one notification read (teacher must own it)
 */
export const markTeacherNotificationAsRead = async (notificationId, teacherId) => {
  const notification = await notificationRepository.findById(notificationId);

  if (!notification) {
    throw new Error("Notification not found");
  }

  if (notification.recipient.toString() !== teacherId.toString()) {
    throw new Error("Unauthorized: This notification does not belong to you");
  }

  return await notificationRepository.markAsRead(notificationId);
};

/**
 * Mark all notifications read for a teacher
 */
export const markAllTeacherNotificationsAsRead = async (teacherId) => {
  return await notificationRepository.markAllAsRead(teacherId);
};

/**
 * Mark notification as read
 */
export const markNotificationAsRead = async (notificationId, studentId) => {
  const notification = await notificationRepository.findById(notificationId);

  if (!notification) {
    throw new Error("Notification not found");
  }

  if (notification.recipient.toString() !== studentId.toString()) {
    throw new Error("Unauthorized: This notification does not belong to you");
  }

  return await notificationRepository.markAsRead(notificationId);
};

/**
 * Mark all notifications as read for a student
 */
export const markAllNotificationsAsRead = async (studentId) => {
  return await notificationRepository.markAllAsRead(studentId);
};

/**
 * Get unread notification count
 */
export const getUnreadCount = async (studentId) => {
  const count = await notificationRepository.getUnreadCount(studentId);
  return count;
};

/**
 * Send an upgrade notification to all students who purchased a specific category or any of its ancestors.
 * Used when a new test or subcategory is added.
 */
export const sendUpgradeNotificationForCategory = async (targetCategoryId, contentName, contentType, sentBy) => {
  try {
    if (!targetCategoryId) return;

    // 1. Get ancestors of targetCategoryId
    const ancestors = [];
    const categoryNames = [];
    let currentId = targetCategoryId.toString();
    while (currentId) {
      ancestors.push(currentId);
      const category = await categoryRepository.findById(currentId);
      if (category) {
        categoryNames.unshift(category.name);
      }
      if (category && category.parent) {
        currentId = category.parent._id ? category.parent._id.toString() : category.parent.toString();
      } else {
        currentId = null;
      }
    }

    // 2. Find all unique students who purchased any of these ancestors
    const purchases = await CategoryPurchase.find({
      categoryId: { $in: ancestors },
      paymentStatus: "completed"
    }).select("student").lean();

    const studentIds = [...new Set(purchases.map(p => p.student.toString()))];

    if (studentIds.length === 0) return;

    // 3. Send notification
    const fullPath = categoryNames.length > 0 ? ` (${categoryNames.join(' > ')})` : '';
    const title = contentType === "test" ? "New Test Added!" : "New Category Added!";
    const body = contentType === "test"
      ? `A new test '${contentName}' has been added in${fullPath}. You can now access it!`
      : `A new subcategory '${contentName}' has been added in${fullPath}. You can now access it!`;

    // sendNotificationToMultipleStudents already exists in this file
    await sendNotificationToMultipleStudents(
      studentIds,
      title,
      body,
      { type: "upgrade", targetCategoryId: targetCategoryId.toString(), contentType },
      sentBy
    );
  } catch (error) {
    console.error("Error in sendUpgradeNotificationForCategory:", error);
  }
};

/**
 * Send a notification to all students who have purchased a category or its ancestors
 * when the category is renamed.
 */
export const sendRenameNotificationForCategory = async (targetCategoryId, oldName, newName, sentBy) => {
  try {
    console.log(`[sendRenameNotificationForCategory] Triggered for category ${targetCategoryId} from '${oldName}' to '${newName}'`);
    if (!targetCategoryId) return;

    const ancestors = [];
    const pathNames = [];
    let currentId = targetCategoryId.toString();
    while (currentId) {
      ancestors.push(currentId);
      const category = await categoryRepository.findById(currentId);
      if (category) {
        pathNames.unshift(currentId === targetCategoryId.toString() ? oldName : category.name);
      }
      if (category && category.parent) {
        currentId = category.parent._id ? category.parent._id.toString() : category.parent.toString();
      } else {
        currentId = null;
      }
    }

    const fullPath = pathNames.join(" > ");

    const purchases = await CategoryPurchase.find({
      $or: [
        { categoryId: { $in: ancestors } },
        { unlockedCategoryIds: targetCategoryId }
      ],
      paymentStatus: "completed"
    }).select("student").lean();

    console.log(`[sendRenameNotificationForCategory] Found ${purchases.length} purchases with access to this category.`);

    const studentIds = [...new Set(purchases.map(p => p.student.toString()))];

    console.log(`[sendRenameNotificationForCategory] Unique student IDs to notify: ${studentIds.length}`);

    if (studentIds.length === 0) return;

    const title = "Category Updated";
    const body = `The category '${fullPath}' has been renamed to '${newName}' by the team.`;

    const result = await sendNotificationToMultipleStudents(
      studentIds,
      title,
      body,
      { type: "system", event: "category_rename", targetCategoryId: targetCategoryId.toString() },
      sentBy
    );
    console.log(`[sendRenameNotificationForCategory] Success: Sent ${result.totalSent} in-app notifications and ${result.fcmSent} push notifications.`);
  } catch (error) {
    console.error("Error in sendRenameNotificationForCategory:", error);
  }
};

/**
 * Send an edit notification to students who purchased a specific test directly,
 * or purchased a subcategory that contains the test.
 * This explicitly excludes notifying students who ONLY purchased the root/pillar categories.
 */
export const sendTestEditNotification = async (testId, testName, categoryId, adminId, oldTestName, changedFieldsList = []) => {
  try {
    let studentIds = [];

    // 1. Direct Test Purchasers
    const directPurchases = await TestPurchase.find({
      test: testId,
      paymentStatus: "completed"
    }).select("student").lean();

    studentIds.push(...directPurchases.map(p => p.student.toString()));

    // 2. Test Bundle Purchasers
    const bundles = await TestBundle.find({ tests: testId }).select("_id").lean();
    if (bundles.length > 0) {
      const bundleIds = bundles.map(b => b._id);
      const bundlePurchases = await TestPurchase.find({
        testBundle: { $in: bundleIds },
        paymentStatus: "completed"
      }).select("student").lean();
      studentIds.push(...bundlePurchases.map(p => p.student.toString()));
    }

    // 3. Tournament Purchasers
    const tournaments = await Tournament.find({ "stages.test": testId }).select("_id").lean();
    if (tournaments.length > 0) {
      const tournamentIds = tournaments.map(t => t._id);
      const tournamentRegistrations = await EventRegistration.find({
        eventId: { $in: tournamentIds },
        eventModel: "Tournament",
        paymentStatus: "completed"
      }).select("student").lean();
      studentIds.push(...tournamentRegistrations.map(r => r.student.toString()));
    }

    // 4. Challenge Participants
    const challenges = await Challenge.find({ test: testId }).select("participants").lean();
    if (challenges.length > 0) {
      challenges.forEach(c => {
        if (c.participants && c.participants.length > 0) {
          studentIds.push(...c.participants.map(p => p.student?.toString()).filter(Boolean));
        }
      });
    }

    // 5. Subcategory Purchasers
    let fullPath = "";
    if (categoryId) {
      const ancestors = [];
      const pathNames = [];
      let currentId = categoryId.toString();
      while (currentId) {
        const category = await categoryRepository.findById(currentId);
        if (category) {
          pathNames.unshift(category.name);
        }
        if (category && category.parent) {
          ancestors.push(currentId);
          currentId = category.parent._id ? category.parent._id.toString() : category.parent.toString();
        } else {
          // This is a root category (pillar), stop traversal
          currentId = null;
        }
      }

      fullPath = pathNames.join(" > ");

      if (ancestors.length > 0) {
        const subcategoryPurchases = await CategoryPurchase.find({
          $or: [
            { categoryId: { $in: ancestors } },
            { unlockedCategoryIds: { $in: ancestors } }
          ],
          paymentStatus: "completed"
        }).select("student").lean();

        studentIds.push(...subcategoryPurchases.map(p => p.student.toString()));
      }
    }

    // Deduplicate student IDs
    studentIds = [...new Set(studentIds)];

    if (studentIds.length === 0) return;

    const nameChangeText = (oldTestName && oldTestName !== testName)
      ? `'${oldTestName}' (now '${testName}')`
      : `'${testName}'`;

    const pathText = fullPath ? ` in ${fullPath}` : "";

    const title = "Test Updated";
    let body = `The test ${nameChangeText}${pathText} has been updated by the team. Check out the latest changes!`;

    if (changedFieldsList && changedFieldsList.length > 0) {
      body += ` (Changes: ${changedFieldsList.join(", ")})`;
    }

    await sendNotificationToMultipleStudents(
      studentIds,
      title,
      body,
      { type: "system", event: "test_update", testId: testId.toString() },
      adminId
    );
  } catch (error) {
    console.error("Error in sendTestEditNotification:", error);
  }
};

export const sendTournamentEditNotification = async (tournamentId, tournamentName, adminId, oldTournamentName, changedFieldsList = []) => {
  try {
    const registrations = await EventRegistration.find({
      eventId: tournamentId,
      eventType: "tournament",
      paymentStatus: "completed"
    }).select("student").lean();

    const studentIds = [...new Set(registrations.map(r => r.student.toString()))];

    if (studentIds.length === 0) return;

    const nameChangeText = (oldTournamentName && oldTournamentName !== tournamentName)
      ? `'${oldTournamentName}' (now '${tournamentName}')`
      : `'${tournamentName}'`;

    const title = "Tournament Updated";
    let body = `The tournament ${nameChangeText} has been updated by the team. Check out the latest changes!`;

    if (changedFieldsList && changedFieldsList.length > 0) {
      body += ` (Changes: ${changedFieldsList.join(", ")})`;
    }

    await sendNotificationToMultipleStudents(
      studentIds,
      title,
      body,
      { type: "system", event: "tournament_update", tournamentId: tournamentId.toString() },
      adminId
    );
  } catch (error) {
    console.error("Error in sendTournamentEditNotification:", error);
  }
};

export const sendOlympiadTestEditNotification = async (olympiadId, olympiadTitle, adminId, oldOlympiadTitle, changedFieldsList = []) => {
  try {
    const registrations = await EventRegistration.find({
      eventId: olympiadId,
      eventType: "olympiad",
      paymentStatus: "completed"
    }).select("student").lean();

    const studentIds = [...new Set(registrations.map(r => r.student.toString()))];

    if (studentIds.length === 0) return;

    const nameChangeText = (oldOlympiadTitle && oldOlympiadTitle !== olympiadTitle)
      ? `'${oldOlympiadTitle}' (now '${olympiadTitle}')`
      : `'${olympiadTitle}'`;

    const title = "Olympiad Test Updated";
    let body = `The Olympiad Test ${nameChangeText} has been updated. Check out the latest changes!`;

    if (changedFieldsList && changedFieldsList.length > 0) {
      body += ` (Changes: ${changedFieldsList.join(", ")})`;
    }

    await sendNotificationToMultipleStudents(
      studentIds,
      title,
      body,
      { type: "system", event: "olympiad_update", olympiadId: olympiadId.toString() },
      adminId
    );

    // Fetch students with their emails
    const studentsResult = await studentRepository.findAll(
      { _id: { $in: studentIds } },
      { limit: 5000 }
    );
    const students = (studentsResult.students || []).filter(s => s.email);

    // Email trigger (fire-and-forget)
    setImmediate(async () => {
      try {
        const { sendEventUpdateEmail } = await import("../utils/sendEmail.js");
        for (const s of students) {
          await sendEventUpdateEmail({
            email: s.email,
            name: s.name,
            eventName: olympiadTitle,
            eventType: "olympiad",
            changedFieldsList,
          });
        }
        console.log(`[OlympiadEmail] Update emails sent for "${olympiadTitle}" to ${students.length} students.`);
      } catch (err) {
        console.error("Error sending olympiad update emails:", err);
      }
    });
  } catch (error) {
    console.error("Error in sendOlympiadTestEditNotification:", error);
  }
};

/**
 * Notify all registered students that the Olympiad exam starts in 10 mins.
 */
export const sendOlympiadStartReminderNotification = async (olympiadId, olympiadTitle, adminId) => {
  try {
    const registrations = await EventRegistration.find({
      eventId: olympiadId,
      eventType: "olympiad",
      paymentStatus: "completed",
    }).select("student").lean();

    const studentIds = [...new Set(registrations.map(r => r.student.toString()))];

    if (studentIds.length === 0) return;

    const title = `${olympiadTitle} starts in 10 mins!`;
    const body = `The Olympiad "${olympiadTitle}" will start in 10 minutes. Get ready to compete!`;

    await sendNotificationToMultipleStudents(
      studentIds,
      title,
      body,
      { type: "event", event: "olympiad_start_reminder", olympiadId: olympiadId.toString() },
      adminId
    );
  } catch (error) {
    console.error("Error in sendOlympiadStartReminderNotification:", error);
  }
};

/**
 * Notify all registered students that the Olympiad exam has started.
 * Called from olympiadNotifications.service.js cron when the startTime is reached.
 */
export const sendOlympiadStartNotification = async (olympiadId, olympiadTitle, adminId) => {
  try {
    const registrations = await EventRegistration.find({
      eventId: olympiadId,
      eventType: "olympiad",
      paymentStatus: "completed",
    }).select("student").lean();

    const studentIds = [...new Set(registrations.map(r => r.student.toString()))];

    if (studentIds.length === 0) return;

    const title = `${olympiadTitle} - Olympiad Has Started!`;
    const body = `The Olympiad "${olympiadTitle}" is now live. Open the app and start your test before time runs out!`;

    await sendNotificationToMultipleStudents(
      studentIds,
      title,
      body,
      { type: "event", event: "olympiad_start", olympiadId: olympiadId.toString() },
      adminId
    );
  } catch (error) {
    console.error("Error in sendOlympiadStartNotification:", error);
  }
};

/**
 * Notify all registered students that the Olympiad results have been declared.
 * Called from olympiadTest.service.js when the admin sets/updates resultDeclarationDate
 * and that date is now or in the past.
 */
export const sendOlympiadResultDeclaredNotification = async (olympiadId, olympiadTitle, adminId) => {
  try {
    const registrations = await EventRegistration.find({
      eventId: olympiadId,
      eventType: "olympiad",
      paymentStatus: "completed",
    }).select("student").lean();

    const studentIds = [...new Set(registrations.map(r => r.student.toString()))];

    if (studentIds.length === 0) return;

    const title = `${olympiadTitle} - Results Declared!`;
    const body = `The results for the Olympiad "${olympiadTitle}" have been officially declared. Check your score and ranking  now!`;

    await sendNotificationToMultipleStudents(
      studentIds,
      title,
      body,
      { type: "event", event: "olympiad_result", olympiadId: olympiadId.toString() },
      adminId
    );
  } catch (error) {
    console.error("Error in sendOlympiadResultDeclaredNotification:", error);
  }
};

/**
 * Notify all admins
 */
export const sendNotificationToAllAdmins = async (title, body, data = {}) => {
  try {
    const admins = await Admin.find({}).select("_id").lean();
    if (admins.length === 0) return;

    const notifications = admins.map((admin) => ({
      title,
      body,
      recipient: admin._id,
      sentBy: null, // System
      data,
      type: data.type || "system",
    }));

    await notificationRepository.createMany(notifications);
  } catch (error) {
    console.error("Error in sendNotificationToAllAdmins:", error);
  }
};

