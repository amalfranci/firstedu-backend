import { ApiError } from "../utils/ApiError.js";
import orderRepository from "../repository/order.repository.js";
import categoryRepository from "../repository/category.repository.js";

/**
 * Get student's order history
 */
export const getStudentOrders = async (studentId, page = 1, limit = 10) => {
  return await orderRepository.findOrders({ student: studentId }, { page, limit });
};

/**
 * Get all orders (for admin)
 */
export const getAllOrders = async (page = 1, limit = 10, filters = {}) => {
  const query = {};
  if (filters.paymentStatus) {
    query.paymentStatus = filters.paymentStatus;
  }
  if (filters.orderStatus) {
    query.orderStatus = filters.orderStatus;
  }
  if (filters.studentId) {
    query.student = filters.studentId;
  }
  if (filters.search && String(filters.search).trim()) {
    const regex = { $regex: String(filters.search).trim(), $options: "i" };
    query.$or = [{ orderNumber: regex }, { paymentId: regex }];
  }

  return await orderRepository.findOrders(query, { page, limit });
};

/**
 * Get order by ID
 */
export const getOrderById = async (orderId) => {
  const order = await orderRepository.findOrderById(orderId);

  if (!order) {
    throw new ApiError(404, "Order not found");
  }

  return order;
};

/**
 * Create order from purchase (helper function)
 * This can be called when a purchase is made
 */
export const createOrderFromPurchase = async (
  studentId,
  items,
  paymentMethod,
  paymentId,
  couponId = null,
  discount = 0,
  pointsUsed = 0
) => {
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const total = Math.max(0, subtotal - discount - pointsUsed);

  // Calculate points earned (e.g., 1 point per 10 rupees spent)
  const pointsEarned = Math.floor(total / 10);

  const order = await orderRepository.createOrder({
    student: studentId,
    items,
    subtotal,
    discount,
    coupon: couponId,
    total,
    paymentMethod,
    paymentId,
    paymentStatus: "completed",
    orderStatus: "confirmed",
    pointsEarned,
    pointsUsed,
  });

  return order;
};

/**
 * Get order history from purchases and claims
 * This aggregates courses, tests, test bundles, events, and merchandise claims
 */
export const getAggregatedOrderHistory = async (
  studentId,
  page = 1,
  limit = 10,
  filters = {}
) => {
  const pageNum = parseInt(page);
  const limitNum = parseInt(limit);
  const skip = (pageNum - 1) * limitNum;
  const { type, from, to, categoryId } = filters;

  const normalizePaymentMethod = (paymentId, fallbackAmount = 0) => {
    if (!paymentId || paymentId === "free" || Number(fallbackAmount) === 0) return "free";
    if (paymentId === "wallet") return "wallet";
    return "razorpay";
  };

  const toNumber = (value, fallback = 0) => {
    const num = Number(value);
    return Number.isFinite(num) ? Math.round(num) : fallback;
  };

  // Get all purchases, registrations and claims
  const [coursePurchases, testPurchases, merchandiseClaims, eventRegistrations, liveCompRegistrations, categoryPurchases] = await Promise.all([
    orderRepository.findCoursePurchases(studentId),
    orderRepository.findTestPurchases(studentId),
    orderRepository.findMerchandiseClaims(studentId),
    orderRepository.findEventRegistrations(studentId),
    orderRepository.findLiveCompetitionRegistrations(studentId),
    orderRepository.findCategoryPurchases(studentId),
  ]);

  // Combine and format into one normalized response
  let allTransactions = [
    ...coursePurchases.map((p) => ({
      id: p._id,
      type: "course",
      date: p.purchaseDate || p.createdAt,
      title: p.course?.title || "Course",
      itemName: p.course?.title || "Course",
      amount: toNumber(p.purchasePrice),
      paymentMethod: normalizePaymentMethod(p.paymentId, p.purchasePrice),
      status: p.paymentStatus,
      data: p,
    })),
    ...testPurchases.map((p) => {
      let resolvedType = "testbundle";
      if (p.test) {
        const appFor = p.test.applicableFor;
        if (appFor === "challenge_yourself") {
          resolvedType = "challenge_yourself";
        } else if (appFor === "challenge_your_friend") {
          resolvedType = "challenge_your_friend";
        } else if (appFor === "everyday_challenge") {
          resolvedType = "everyday_challenge";
        } else if (appFor === "competition_sector" || appFor === "competitive") {
          resolvedType = "competitive";
        } else if (appFor === "school") {
          resolvedType = "school";
        } else if (appFor === "skill development" || appFor === "skill") {
          resolvedType = "skill development";
        } else {
          resolvedType = "test";
        }
      }

      return {
        id: p._id,
        type: resolvedType,
        date: p.purchaseDate || p.createdAt,
        title: p.test?.title || p.competitionCategory?.title || p.testBundle?.name || "Test/Bundle",
        itemName: p.test?.title || p.competitionCategory?.title || p.testBundle?.name || "Test/Bundle",
        amount: toNumber(p.purchasePrice),
        paymentMethod: normalizePaymentMethod(p.paymentId, p.purchasePrice),
        status: p.paymentStatus,
        data: p,
      };
    }),
    ...eventRegistrations.map((r) => {
      const fallbackAmount = toNumber(r.eventId?.price);
      const amountPaid =
        r.amountPaid !== undefined && r.amountPaid !== null
          ? toNumber(r.amountPaid)
          : fallbackAmount;
      const methodFromModel =
        r.paymentMethod && ["free", "wallet", "razorpay"].includes(r.paymentMethod)
          ? r.paymentMethod
          : null;

      return {
        id: r._id,
        type: r.eventType,
        date: r.registeredAt || r.createdAt,
        title: r.eventId?.title || r.eventType,
        itemName: r.eventId?.title || r.eventType,
        amount: amountPaid,
        paymentMethod:
          methodFromModel || normalizePaymentMethod(r.paymentId, amountPaid),
        status: r.paymentStatus,
        data: r,
      };
    }),
    ...liveCompRegistrations.map((lc) => {
      const targetRound = lc.round === "GRAND_FINALE" ? lc.event?.grandFinale : lc.event?.megaAudition;
      const fallbackAmount = toNumber(targetRound?.fee?.amount);
      const amountPaid = fallbackAmount; // Live competition submission doesn't currently store `amountPaid` directly
      
      const roundLabel = lc.round === 'GRAND_FINALE' ? 'Grand Finale' : 'Mega Audition';
      const eventTitle = lc.event?.title || "Live Competition";
      const derivedMethod = lc.transactionId ? "razorpay" : (amountPaid === 0 ? "free" : "wallet");

      return {
        id: lc._id,
        type: "live_competition",
        date: lc.createdAt,
        title: `${eventTitle} (${roundLabel})`,
        itemName: `${eventTitle} (${roundLabel})`,
        amount: amountPaid,
        paymentMethod: normalizePaymentMethod(derivedMethod, amountPaid),
        status: lc.paymentStatus,
        data: lc,
      };
    }),
    ...merchandiseClaims.map((c) => ({
      id: c._id,
      type: "merchandise",
      date: c.claimedAt || c.createdAt,
      title: c.merchandise?.name || "Merchandise",
      itemName: c.merchandise?.name || "Merchandise",
      amount: c.paymentMethod === "points" ? toNumber(c.pointsSpent) : toNumber(c.moneyPaid),
      paymentMethod: c.paymentMethod,
      // Dynamically derive paymentStatus – points are always completed; for wallet/gateway use moneyPaid presence
      paymentStatus: c.paymentMethod === "points" ? "completed" : (toNumber(c.moneyPaid) > 0 ? "completed" : "pending"),
      // Preserve original delivery status for backward compatibility
      status: c.status,
      amountUnit: c.paymentMethod === "points" ? "points" : undefined,
      data: c,
    })),
    ...categoryPurchases.map((p) => {
      const catName = p.categoryId?.name ? `${p.pillarType} - ${p.categoryId.name}` : p.pillarType || "Category";
      return {
        id: p._id,
        type: p.pillarType,
        date: p.createdAt,
        title: catName,
        itemName: catName,
        amount: toNumber(p.purchasePrice),
        paymentMethod: normalizePaymentMethod(p.paymentId, p.purchasePrice),
        status: p.paymentStatus,
        data: p,
      };
    }),
  ].sort((a, b) => new Date(b.date) - new Date(a.date));

  const normalizeType = (value) => {
    if (!value) return null;
    const normalized = String(value).trim().toLowerCase();
    const aliases = {
      bundle: "testbundle",
      "test-bundle": "testbundle",
      test_bundle: "testbundle",
      testbundle: "testbundle",
      olympiad: "olympiads",
      olympiads: "olympiads",
      "skill development": "skill-development",
      "skill_development": "skill-development",
    };
    return aliases[normalized] || normalized;
  };

  // Type filter (?type=course or ?type=course,test)
  if (type) {
    const requestedTypes = String(type)
      .split(",")
      .map((item) => normalizeType(item))
      .filter(Boolean);

    let expandedTypes = [...requestedTypes];
    if (expandedTypes.includes("gamification")) {
      expandedTypes.push("challenge_yourself", "challenge_your_friend", "everyday_challenge");
    }

    if (expandedTypes.length > 0) {
      allTransactions = allTransactions.filter((t) =>
        expandedTypes.includes(normalizeType(t.type))
      );
    }
  }

  // Category ID filter (?categoryId=64a2f9...)
  if (categoryId) {
    let descendantIds = [categoryId.toString()];
    let includesTournamentCategory = false;
    try {
      descendantIds = await categoryRepository.findDescendantIds(categoryId);
      // Check if the selected category or any descendant is named "tournament"
      for (const id of descendantIds) {
        const cat = await categoryRepository.findById(id);
        if (cat?.name && cat.name.toLowerCase().includes("tournament")) {
          includesTournamentCategory = true;
          break;
        }
      }
    } catch (err) {
      // Fallback to exact match if categoryId is an invalid ObjectId
      console.warn(`[OrderService] Invalid categoryId passed to filter: ${categoryId}`);
    }

    allTransactions = allTransactions.filter((t) => {
      // Force include global tournaments if a tournament category is selected
      if (includesTournamentCategory && t.type === "tournament") {
        return true;
      }
      if (t.type === "course") {
        return t.data?.course?.categoryIds?.some((id) =>
          descendantIds.includes(id.toString()) || descendantIds.includes(id._id?.toString())
        );
      }
      
      const testTypes = ["test", "testbundle", "competitive", "school", "skill development", "gamification"];
      if (testTypes.includes(t.type)) {
        const testCatId = t.data?.test?.categoryId?.toString() || t.data?.test?.categoryId?._id?.toString();
        const qbCatId = t.data?.test?.questionBank?.categories?.[0]?.toString() || t.data?.test?.questionBank?.categories?.[0]?._id?.toString();
        return descendantIds.includes(testCatId) || descendantIds.includes(qbCatId);
      }
      
      const eventTypes = ["olympiad", "olympiads", "tournament", "workshop", "live_competition"];
      if (eventTypes.includes(t.type)) {
        const eventCatId = t.data?.eventId?.categoryId?.toString() || t.data?.eventId?.categoryId?._id?.toString();
        return descendantIds.includes(eventCatId);
      }
      
      if (t.data?.categoryId) {
        const catId = t.data?.categoryId?._id?.toString() || t.data?.categoryId?.toString();
        return descendantIds.includes(catId);
      }
      
      return false;
    });
  }

  // Date filters (?from=2026-01-01&to=2026-01-31)
  if (from) {
    const fromDate = new Date(from);
    if (Number.isNaN(fromDate.getTime())) {
      throw new ApiError(400, "Invalid 'from' date");
    }
    allTransactions = allTransactions.filter((t) => new Date(t.date) >= fromDate);
  }

  if (to) {
    const toDate = new Date(to);
    if (Number.isNaN(toDate.getTime())) {
      throw new ApiError(400, "Invalid 'to' date");
    }
    // Include full end day when only a date is provided (YYYY-MM-DD)
    if (typeof to === "string" && !to.includes("T")) {
      toDate.setHours(23, 59, 59, 999);
    }
    allTransactions = allTransactions.filter((t) => new Date(t.date) <= toDate);
  }

  // Paginate
  const total = allTransactions.length;
  const paginatedTransactions = allTransactions.slice(skip, skip + limitNum);

  return {
    transactions: paginatedTransactions,
    pagination: {
      page: pageNum,
      limit: limitNum,
      total,
      pages: Math.ceil(total / limitNum) || 1,
    },
  };
};

export default {
  getStudentOrders,
  getAllOrders,
  getOrderById,
  createOrderFromPurchase,
  getAggregatedOrderHistory,
};

