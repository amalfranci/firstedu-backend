import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import { ApiResponse } from "../utils/ApiResponse.js";
import merchandiseService from "../services/merchandise.service.js";
import merchandiseValidator from "../validation/merchandise.validator.js";
import walletService from "../services/wallet.service.js";
import { attachOfferToList, attachOfferToItem } from "../utils/offerUtils.js";

/**
 * Get all merchandise items
 */
export const getMerchandiseItems = asyncHandler(async (req, res) => {
  const { page = 1, limit = 10 } = req.query;
  const studentId = req.user._id;

  const result = await merchandiseService.getMerchandiseItems(page, limit);
  const itemsWithOffers = await attachOfferToList(result.items, "Merchandise");

  const wallet = await walletService.getOrCreateWallet(studentId, "User");
  const meta = {
    ...result.pagination,
    totalPoints: wallet.rewardPoints ?? 0,
    monetaryBalance: wallet.monetaryBalance ?? 0,
  };

  return res.status(200).json(
    ApiResponse.success(
      itemsWithOffers,
      "Merchandise items fetched successfully",
      meta
    )
  );
});

/**
 * Get merchandise item by ID
 */
export const getMerchandiseById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const studentId = req.user._id;

  const item = await merchandiseService.getMerchandiseById(id);
  const itemWithOffer = await attachOfferToItem(item, "Merchandise");

  const wallet = await walletService.getOrCreateWallet(studentId, "User");
  const plainItem = itemWithOffer?.toObject ? itemWithOffer.toObject() : { ...itemWithOffer };
  const data = {
    ...plainItem,
    totalPoints: wallet.rewardPoints ?? 0,
    monetaryBalance: wallet.monetaryBalance ?? 0,
  };

  return res
    .status(200)
    .json(ApiResponse.success(data, "Merchandise item fetched successfully"));
});

/**
 * Claim merchandise via points (Direct Claim)
 * Supports paymentMethod: "points"
 */
export const claimMerchandise = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const studentId = req.user._id;

  const item = await merchandiseService.getMerchandiseById(id);

  const { error, value } = merchandiseValidator.claimMerchandise.validate(
    req.body,
    { context: { isPhysical: item.isPhysical } }
  );

  if (error) {
    const errorMessage = error.details.map(x => x.message).join(", ");
    throw new ApiError(400, errorMessage);
  }

  const result = await merchandiseService.claimMerchandise(studentId, id, value);

  return res.status(201).json(ApiResponse.success(result, "Merchandise claimed successfully with points"));
});

/**
 * Initiate Merchandise Payment (for free, wallet, razorpay)
 */
export const initiateMerchandisePayment = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const studentId = req.user._id;

  const item = await merchandiseService.getMerchandiseById(id);

  const { error, value } = merchandiseValidator.initiateMerchandisePayment.validate(
    req.body,
    { context: { isPhysical: item.isPhysical } }
  );

  if (error) {
    const errorMessage = error.details.map(x => x.message).join(", ");
    throw new ApiError(400, errorMessage);
  }

  const { paymentMethod, ...options } = value;
  const result = await merchandiseService.initiateMerchandisePayment(id, studentId, paymentMethod, options);

  if (!result.completed) {
    return res.status(200).json(ApiResponse.success(result, "Payment initiation successful"));
  }

  return res.status(201).json(ApiResponse.success(result.claim, "Merchandise claimed successfully"));
});

/**
 * Confirm Merchandise Payment (for Razorpay)
 */
export const confirmMerchandisePayment = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const studentId = req.user._id;

  const item = await merchandiseService.getMerchandiseById(id);

  const { error, value } = merchandiseValidator.confirmMerchandisePayment.validate(
    req.body,
    { context: { isPhysical: item.isPhysical } }
  );

  if (error) {
    const errorMessage = error.details.map(x => x.message).join(", ");
    throw new ApiError(400, errorMessage);
  }

  const result = await merchandiseService.confirmMerchandisePayment(id, studentId, value);

  return res.status(201).json(ApiResponse.success(result, "Merchandise payment verified and claimed successfully"));
});

/**
 * Get student's merchandise claims
 */
export const getMyClaims = asyncHandler(async (req, res) => {
  const studentId = req.user._id;
  const { page = 1, limit = 10 } = req.query;

  const result = await merchandiseService.getStudentClaims(studentId, page, limit);

  return res.status(200).json(
    ApiResponse.success(
      result.claims,
      "Merchandise claims fetched successfully",
      result.pagination
    )
  );
});

export default {
  getMerchandiseItems,
  getMerchandiseById,
  claimMerchandise,
  initiateMerchandisePayment,
  confirmMerchandisePayment,
  getMyClaims,
};
