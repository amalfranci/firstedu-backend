import mongoose from "mongoose";

const sectionSchema = new mongoose.Schema(
  {
    id: { type: Number },
    name: { type: String, trim: true },
    count: { type: Number, required: true, min: 1 },
    difficulty: {
      type: String,
      enum: ["easy", "medium", "hard"],
      required: true,
    },
    timeMinutes: { type: Number, min: 0, default: 0 },
    questions: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Question",
      },
    ],
  },
  { _id: false }
);

const questionBankSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    categories: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Category",
      },
    ],
    useSectionWiseDifficulty: {
      type: Boolean,
      default: false,
    },
    overallDifficulty: {
      type: String,
      enum: ["easy", "medium", "hard"],
      default: "medium",
    },
    sections: [sectionSchema],
    useSectionWiseQuestions: {
      type: Boolean,
      default: false,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Admin",
      required: true,
    },
    /** Set only when this bank was copied from a seeded competitive paper. */
    seedPaperKey: {
      type: String,
      trim: true,
    },
  },
  { timestamps: true }
);

questionBankSchema.index({ categories: 1 });
questionBankSchema.index({ createdBy: 1, createdAt: -1 });
questionBankSchema.index(
  { seedPaperKey: 1 },
  {
    unique: true,
    partialFilterExpression: { seedPaperKey: { $type: "string" } },
  }
);

export default mongoose.models.QuestionBank ||
  mongoose.model("QuestionBank", questionBankSchema);
