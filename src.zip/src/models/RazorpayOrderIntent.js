import mongoose from "mongoose";

/** Tracks Razorpay order -> (student, type, entity) for webhook reconciliation on payment.captured */
const razorpayOrderIntentSchema = new mongoose.Schema(
  {
    orderId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    studentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },
    type: {
      type: String,
      required: true,
      enum: [
        "course",
        "test",
        "bundle",
        "tournament",
        "workshop",
        "wallet",
        "live_competition",
        "categoryNode",
        "Olympiads",
        "School",
        "Competitive",
        "Skill Development",
        "categoryUpgrade",
        "merchandise",
      ],
      index: true,
    },
    entityId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      refPath: "entityModel",
      index: true,
    },
    entityModel: {
      type: String,
      required: true,
      enum: [
        "Course",
        "Test",
        "TestBundle",
        "Olympiad",
        "OlympiadTest",
        "Tournament",
        "Workshop",
        "User",
        "CompetitionCategory",
        "LiveCompetition",
        "Category",
        "CategoryPurchase",
        "Merchandise",
      ],
    },
    amountPaise: { type: Number, required: true },
    currency: { type: String, default: "INR" },
    receipt: { type: String, trim: true },
    couponId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Coupon",
      default: null,
    },
    reconciled: { type: Boolean, default: false, index: true },
    reconciledAt: { type: Date },
    paymentId: { type: String, trim: true },
    metadata: {
      type: mongoose.Schema.Types.Mixed,
      default: {},
    },
  },
  { timestamps: true },
);

razorpayOrderIntentSchema.index({ reconciled: 1, createdAt: 1 });

export default mongoose.models.RazorpayOrderIntent ||
  mongoose.model("RazorpayOrderIntent", razorpayOrderIntentSchema);
